public interface Variation {
	public Point calculate(double x, double y);
}
