
public class VariationGenerator {
	public static Variation generateVarations() {
		return null;
	}
}
